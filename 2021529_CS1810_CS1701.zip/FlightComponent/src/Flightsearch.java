import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Flightsearch {
	public static void main(String [] args) throws Exception{
		Scanner sc = new Scanner(System.in);
		String[] arr;
		ArrayList<String> ar = new ArrayList<String>();
		String flightpath = "C:\\Users\\maria\\eclipse-workspace\\FlightComponent\\src\\Flights.csv";
		String line = "";
		System.out.println("Enter Dperture City");
		String depCity = sc.nextLine();
		System.out.println("Enter Arrival City");
		String arrCity = sc.nextLine();
		System.out.println("Enter Departure Date");
		String depDate = sc.nextLine();
		System.out.println("Enter Return Date");
		String retDate = sc.nextLine();
		 
		
		try {
			BufferedReader fs = new BufferedReader(new FileReader(flightpath));
			while ((line = fs.readLine()) !=null) {
				arr = line.split(",");
				if(arr[7].equals(depCity) && arr[9].equals(arrCity) && arr[0].equals(depDate)) {
					System.out.println("Departure Flight ");
					System.out.println(arr[0] + " "+ arr[1] + " " + arr[2] + " " + arr[3] + " " + arr[4] + " " + arr[5] + " " + arr[6] + " " + arr[7] + " " + arr[8] + " " + arr[9] + " " + arr[10] + " " + arr[11]);
				}
			}
			
			}catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		try {
			BufferedReader fs = new BufferedReader(new FileReader(flightpath));
			while ((line = fs.readLine()) !=null) {
				arr = line.split(",");
				if(arr[7].equals(arrCity) && arr[9].equals(depCity) && arr[0].equals(retDate)) {
					System.out.println("Return Flight ");
					System.out.println(arr[0] + " "+ arr[1] + " " + arr[2] + " " + arr[3] + " " + arr[4] + " " + arr[5] + " " + arr[6] + " " + arr[7] + " " + arr[8] + " " + arr[9] + " " + arr[10] + " " + arr[11]);
				} 
		}
			}catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
	}		
}
