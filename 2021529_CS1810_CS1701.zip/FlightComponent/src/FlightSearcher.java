import java.io.File;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class FlightSearcher {
	private static Scanner x;
	
	
public static void main(String[] args) {
	String filepath = "C:\\Users\\maria\\eclipse-workspace\\FlightComponent\\src";
	Scanner details = new Scanner(System.in);
	System.out.println("Enter the departure city:");
	String depCity = details.nextLine();
	System.out.println("Enter the arrival city:");
	String arvCity = details.nextLine();
	System.out.println("Enter the departure date:");
	String depDate = details.nextLine();
	System.out.println("Enter the arrival date:");
	String arvDate = details.nextLine();
	
	String searchFlight = arvDate + depDate + arvCity + depCity;


}

public static void readFlights(String filepath, String searchFlight) {
	
	boolean found = false;
	String	DateofFlight = ""; String DepartureTime = ""; String ArrivalTime = ""; String FlightDuration = ""; String DistanceTravelled = ""; String Delay = "";String DepartureAirport = "";String DepartureCity = "";String ArrivalAirport = "";String ArrivalCity = "" ; String FlightNumber = "";String Airline = ""; 
	try 
	{
		x = new Scanner(new File(filepath));
		x.useDelimiter("[,\n]");
		while(x.hasNext() && !found )
		{
			DateofFlight = x.next();
			DepartureTime = x.next();
			ArrivalTime = x.next();
			FlightDuration = x.next();
			DistanceTravelled = x.next();
			Delay = x.next();
			DepartureAirport = x.next();
			DepartureCity = x.next();
			ArrivalAirport = x.next();
			ArrivalCity = x.next();
			FlightNumber = x.next();
			Airline = x.next();
			
			if(DepartureTime.equals(searchFlight))
			{
				found = true;
			}
		}
		
		if(found)
		{
			JOptionPane.showMessageDialog(null, "DateofFlight :" + DateofFlight + "DepartureTime" + DepartureTime + "ArrivalTime" + ArrivalTime + "");
		}
	}
	catch(Exception e) {
		
	}
}
}