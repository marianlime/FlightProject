import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;

public class FlightsAvailable extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTable table_1;
	String ArrCity;
	String deprDate;
	String retrnDate;
	String DepCity;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FlightsAvailable frame = new FlightsAvailable();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	String[] arr;
	ArrayList<String> ar = new ArrayList<String>();
	String flightpath = "C:\\\\Users\\\\maria\\\\eclipse-workspace\\\\FlightComponent\\src\\Flights.csv";
	String line = "";
	private JTable table_2;{
	
	try {
		BufferedReader fs = new BufferedReader(new FileReader(flightpath));
		while ((line = fs.readLine()) !=null) {
			arr = line.split(",");
			if(arr[7].equals(DepCity) && arr[9].equals(ArrCity) && arr[0].equals(deprDate)) {	
			}
		}
		
		}catch (IOException e) {
		e.printStackTrace();
	}
	try {
		BufferedReader fs = new BufferedReader(new FileReader(flightpath));
		while ((line = fs.readLine()) !=null) {
			arr = line.split(",");
			if(arr[7].equals(ArrCity) && arr[9].equals(DepCity) && arr[0].equals(retrnDate)) {
			} 
	}
		}catch (FileNotFoundException e1) {
		e1.printStackTrace();
	} catch (IOException e) {
			e.printStackTrace();
		}
	}
	

	/**
	 * Create the frame.
	 */
	public FlightsAvailable() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1063, 732);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		table = new JTable();
		table.setBounds(753, 297, -353, -128);
		contentPane.add(table);
		
		JLabel lblNewLabel = new JLabel("Flights Available");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblNewLabel.setBounds(42, 23, 315, 57);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("SeatingPlan");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"This part has not been inplemented yet !",null, JOptionPane.ERROR_MESSAGE);
			}
		});
		btnNewButton.setBounds(160, 571, 123, 50);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Purchase");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"This part has not been inplemented yet !",null, JOptionPane.ERROR_MESSAGE);
			}
		});
		btnNewButton_1.setBounds(42, 632, 123, 50);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_1 = new JLabel("Departure Flights");
		lblNewLabel_1.setBounds(52, 97, 99, 14);
		contentPane.add(lblNewLabel_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(55, 122, 867, 182);
		contentPane.add(scrollPane);
		
		table_1 = new JTable();
		scrollPane.setViewportView(table_1);
		table_1.setModel(new DefaultTableModel(
			new Object[][] {
				{arr[7], arr[6], arr[9], arr[8], arr[1], arr[2], arr[10]},
			},
			new String[] {
				"Departing City", "Airport", "Arriving City", "Airport", "Departure Time", "Arrival Time", "Flight Number"
			}
		));
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(52, 399, 865, 151);
		contentPane.add(scrollPane_1);
		
		table_2 = new JTable();
		scrollPane_1.setViewportView(table_2);
		table_2.setModel(new DefaultTableModel(
			new Object[][] {
				{arr[9], arr[8], arr[7], arr[6], arr[1], arr[2], arr[10]},
			},
			new String[] {
				"Departing City", "Ariport", "Arriving City", "Airport", "Departure Time ", "Arrival Time", "Flight Number"
			}
		));
		table_2.getColumnModel().getColumn(0).setPreferredWidth(93);
		table_2.getColumnModel().getColumn(4).setPreferredWidth(93);
		table_2.getColumnModel().getColumn(6).setPreferredWidth(88);
		
		JLabel lblNewLabel_1_1 = new JLabel("Arrival Flights");
		lblNewLabel_1_1.setBounds(55, 374, 99, 14);
		contentPane.add(lblNewLabel_1_1);
		table_1.getColumnModel().getColumn(0).setPreferredWidth(88);
		table_1.getColumnModel().getColumn(4).setPreferredWidth(89);
	}
}
